export type Point2D = { x: number; y: number };
export type LineSegment = { start: Point2D; end: Point2D };

export function cross(u: number[], v: number[]): number[] {
  return [
    u[1] * v[2] - u[2] * v[1],
    u[2] * v[0] - u[0] * v[2],
    u[0] * v[1] - u[1] * v[0],
  ];
}

export function dot(u: number[], v: number[]): number {
  return u[0] * v[0] + u[1] * v[1] + u[2] * v[2];
}

export function normalize(v: number[]): number[] {
  const len = Math.hypot(v[0], v[1], v[2]);
  if (len === 0) return v;
  return [v[0] / len, v[1] / len, v[2] / len];
}

export function getLineIntersection(line1: LineSegment, line2: LineSegment): number[] {
  const l1 = cross([line1.start.x, line1.start.y, 1], [line1.end.x, line1.end.y, 1]);
  const l2 = cross([line2.start.x, line2.start.y, 1], [line2.end.x, line2.end.y, 1]);
  return cross(l1, l2); // homogeneous [x, y, w]
}

export function multiplyMatVec(M: number[][], v: number[]): number[] {
  return [
    M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2],
    M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2],
    M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2],
  ];
}

// Calculate focal length from two orthogonal vanishing points
export function calculateFocalLength(VPx: number[], VPy: number[], cx: number, cy: number): number | null {
  if (VPx[2] === 0 || VPy[2] === 0) return null; // One VP is at infinity
  
  const vx = VPx[0] / VPx[2] - cx;
  const vy = VPx[1] / VPx[2] - cy;
  const ux = VPy[0] / VPy[2] - cx;
  const uy = VPy[1] / VPy[2] - cy;
  
  const f2 = -(vx * ux + vy * uy);
  if (f2 > 0) return Math.sqrt(f2);
  return null; // Orthogonality implies f2 > 0. If negative, lines are not orthogonal or principal point is very wrong.
}

export function getOrthogonalBasis(
  VPx: number[] | null,
  VPy: number[] | null,
  VPz: number[] | null,
  f: number, cx: number, cy: number
) {
  const Kinv = [
    [1 / f, 0, -cx / f],
    [0, 1 / f, -cy / f],
    [0, 0, 1],
  ];

  let Rx: number[] | null = null;
  let Ry: number[] | null = null;
  let Rz: number[] | null = null;

  if (VPx) Rx = normalize(multiplyMatVec(Kinv, VPx));
  if (VPy) Ry = normalize(multiplyMatVec(Kinv, VPy));
  if (VPz) Rz = normalize(multiplyMatVec(Kinv, VPz));

  // Enforce perfect orthogonality.
  if (Rx && Ry) {
    Rz = normalize(cross(Rx, Ry));
    Ry = normalize(cross(Rz, Rx));
    Rx = normalize(cross(Ry, Rz));
  } else if (Rx && Rz) {
    Ry = normalize(cross(Rz, Rx));
    Rz = normalize(cross(Rx, Ry));
    Rx = normalize(cross(Ry, Rz));
  } else if (Ry && Rz) {
    Rx = normalize(cross(Ry, Rz));
    Rz = normalize(cross(Rx, Ry));
    Ry = normalize(cross(Rz, Rx));
  } else {
    return null;
  }

  return { Rx, Ry, Rz };
}

export function getUnscaledDistanceRobust(
  p1: Point2D,
  p2: Point2D,
  basis: { Rx: number[], Ry: number[], Rz: number[] },
  measurePlane: 'XZ' | 'XY' | 'YZ',
  f: number,
  cx: number,
  cy: number
): number | null {
  const { Rx, Ry, Rz } = basis;
  
  // Determine plane normal based on chosen plane
  let N: number[];
  if (measurePlane === 'XZ') N = Ry;
  else if (measurePlane === 'XY') N = Rz;
  else N = Rx; // YZ

  const Kinv = [
    [1 / f, 0, -cx / f],
    [0, 1 / f, -cy / f],
    [0, 0, 1],
  ];

  const ray1 = multiplyMatVec(Kinv, [p1.x, p1.y, 1]);
  const ndot1 = dot(N, ray1);
  if (Math.abs(ndot1) < 1e-6) return null; 
  const d1 = 1 / ndot1;
  const P1 = [ray1[0] * d1, ray1[1] * d1, ray1[2] * d1];

  const ray2 = multiplyMatVec(Kinv, [p2.x, p2.y, 1]);
  const ndot2 = dot(N, ray2);
  if (Math.abs(ndot2) < 1e-6) return null;
  const d2 = 1 / ndot2;
  const P2 = [ray2[0] * d2, ray2[1] * d2, ray2[2] * d2];

  return Math.hypot(P1[0] - P2[0], P1[1] - P2[1], P1[2] - P2[2]);
}
