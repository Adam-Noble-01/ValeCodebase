#!/usr/bin/env python
"""
Test script for Video Combiner to check logging and functionality
Run this after the main script to check the log file
"""

import os
from datetime import datetime

def check_log_file():
    """Check the video_combiner.log for debug information"""
    log_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'video_combiner.log')
    
    if not os.path.exists(log_path):
        print("Log file not found!")
        return
    
    # Read last 100 lines of log
    with open(log_path, 'r') as f:
        lines = f.readlines()
        
    print(f"\n=== Last entries from video_combiner.log ===")
    print(f"Log file: {log_path}\n")
    
    # Find entries from the last run (look for "Refreshed video list")
    last_run_index = -1
    for i in range(len(lines) - 1, -1, -1):
        if "Refreshed video list" in lines[i]:
            last_run_index = i
            break
    
    if last_run_index >= 0:
        print("--- Last Run Details ---")
        for line in lines[last_run_index:]:
            print(line.strip())
    else:
        print("--- Last 50 lines ---")
        for line in lines[-50:]:
            print(line.strip())

if __name__ == "__main__":
    check_log_file() 