import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Point2D, LineSegment, getLineIntersection, calculateFocalLength, getUnscaledDistanceRobust, getOrthogonalBasis } from '../lib/math';

export type AppMode = 'setup' | 'constraint' | 'measure' | 'ortho';

export type DrawnLine = LineSegment & {
  id: string;
  type: 'x' | 'y' | 'z' | 'constraint' | 'measure';
  lengthInput?: number; // the real world length set by user
};

interface PerspectiveCanvasProps {
  imageUrl: string;
  lines: DrawnLine[];
  setLines: React.Dispatch<React.SetStateAction<DrawnLine[]>>;
  mode: AppMode;
  selectedLineId: string | null;
  setSelectedLineId: (id: string | null) => void;
  onScaleDetermined: (scale: number | null) => void;
  metadataFocalPixels: number | null;
  dimensionSize: number;
  constraintPlane: 'XZ' | 'XY' | 'YZ';
  measurePlane: 'XZ' | 'XY' | 'YZ';
  showDepthMap: boolean;
}

export default function PerspectiveCanvas({
  imageUrl,
  lines,
  setLines,
  mode,
  selectedLineId,
  setSelectedLineId,
  onScaleDetermined,
  metadataFocalPixels,
  dimensionSize,
  constraintPlane,
  measurePlane,
  showDepthMap
}: PerspectiveCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  
  const [imgSize, setImgSize] = useState<{ w: number; h: number }>({ w: 1, h: 1 });
  
  // Navigation State
  const [transform, setTransform] = useState({ x: 0, y: 0, scale: 1 });
  const isPanning = useRef(false);
  const lastPan = useRef({ x: 0, y: 0 });

  // Dragging State
  const draggingPointRef = useRef<{ lineId: string; end: 'start' | 'end' } | null>(null);
  const [drawingNewLine, setDrawingNewLine] = useState<DrawnLine | null>(null);
  const [isHoveringPoint, setIsHoveringPoint] = useState(false);

  useEffect(() => {
    const img = new Image();
    img.src = imageUrl;
    img.onload = () => {
      setImgSize({ w: img.width, h: img.height });
      
      const container = containerRef.current;
      if (container) {
          const rect = container.getBoundingClientRect();
          const scaleW = rect.width / img.width;
          const scaleH = rect.height / img.height;
          const fitScale = Math.min(scaleW, scaleH) * 0.95; // 95% margin fit
          
          const fitX = (rect.width - (img.width * fitScale)) / 2;
          const fitY = (rect.height - (img.height * fitScale)) / 2;
          
          setTransform({ x: fitX, y: fitY, scale: fitScale });
      } else {
          setTransform({ x: 0, y: 0, scale: 1 });
      }
      
      // Auto-populate setup lines if empty
      setLines(prev => {
        if (prev.some(l => l.type === 'x' || l.type === 'y' || l.type === 'z')) return prev;
        const w = img.width;
        const h = img.height;
        return [
          { id: 'x1', type: 'x', start: { x: w * 0.1, y: h * 0.7 }, end: { x: w * 0.9, y: h * 0.75 } },
          { id: 'x2', type: 'x', start: { x: w * 0.1, y: h * 0.3 }, end: { x: w * 0.9, y: h * 0.25 } },
          { id: 'y1', type: 'y', start: { x: w * 0.2, y: h * 0.1 }, end: { x: w * 0.18, y: h * 0.9 } }, // Vertical (Height)
          { id: 'y2', type: 'y', start: { x: w * 0.8, y: h * 0.1 }, end: { x: w * 0.82, y: h * 0.9 } }, // Vertical (Height)
          { id: 'z1', type: 'z', start: { x: w * 0.6, y: h * 0.8 }, end: { x: w * 0.9, y: h * 0.9 } }, // Depth
          { id: 'z2', type: 'z', start: { x: w * 0.6, y: h * 0.4 }, end: { x: w * 0.8, y: h * 0.6 } }, // Depth
        ];
      });
    };
  }, [imageUrl, setLines]);

  // Handle Zoom Wheel
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const rect = el.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;

      const scaleAdjust = e.deltaY > 0 ? 0.9 : 1.1; // 10% zoom per tick
      
      setTransform(prev => {
        const nextScale = Math.min(Math.max(prev.scale * scaleAdjust, 0.1), 30);
        const newX = mx - (mx - prev.x) * (nextScale / prev.scale);
        const newY = my - (my - prev.y) * (nextScale / prev.scale);
        return { x: newX, y: newY, scale: nextScale };
      });
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, []);

  const getSvgPoint = (clientX: number, clientY: number) => {
    if (!containerRef.current) return { x: 0, y: 0 };
    const rect = containerRef.current.getBoundingClientRect();
    const dx = clientX - rect.left;
    const dy = clientY - rect.top;
    return {
      x: (dx - transform.x) / transform.scale,
      y: (dy - transform.y) / transform.scale
    };
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    e.currentTarget.setPointerCapture(e.pointerId);

    // Right or Middle click for panning
    if (e.button === 1 || e.button === 2) {
       e.preventDefault();
       isPanning.current = true;
       lastPan.current = { x: e.clientX, y: e.clientY };
       return;
    }

    e.preventDefault();
    if (draggingPointRef.current) return;
    
    const pt = getSvgPoint(e.clientX, e.clientY);
    const hitRadiusTarget = 30 / transform.scale; // flawlessly fixed visual hit radius of precisely 30 screen pixels
    
    let closestPoint = null;
    let minDistance = hitRadiusTarget;

    for (const l of lines) {
      const distStart = Math.hypot(l.start.x - pt.x, l.start.y - pt.y);
      if (distStart <= minDistance) {
        closestPoint = { lineId: l.id, end: 'start' as const };
        minDistance = distStart;
      }
      
      const distEnd = Math.hypot(l.end.x - pt.x, l.end.y - pt.y);
      if (distEnd <= minDistance) {
        closestPoint = { lineId: l.id, end: 'end' as const };
        minDistance = distEnd;
      }
    }
    
    if (closestPoint) {
      draggingPointRef.current = closestPoint;
      setSelectedLineId(closestPoint.lineId);
      return;
    }
    
    if (mode === 'constraint' || mode === 'measure') {
      const newLine: DrawnLine = {
          id: `${mode}_${Date.now()}`,
          type: mode,
          start: pt,
          end: pt,
          lengthInput: mode === 'constraint' ? 1000 : undefined
        };
        setDrawingNewLine(newLine);
        setSelectedLineId(newLine.id);
      } else {
        setSelectedLineId(null);
      }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (isPanning.current) {
        const dx = e.clientX - lastPan.current.x;
        const dy = e.clientY - lastPan.current.y;
        setTransform(prev => ({ ...prev, x: prev.x + dx, y: prev.y + dy }));
        lastPan.current = { x: e.clientX, y: e.clientY };
        return;
    }

    const pt = getSvgPoint(e.clientX, e.clientY);
    
    if (draggingPointRef.current) {
      const dp = draggingPointRef.current;
      setLines(prev => prev.map(l => {
        if (l.id === dp.lineId) {
          return { ...l, [dp.end]: pt };
        }
        return l;
      }));
    } else if (drawingNewLine) {
      setDrawingNewLine(prev => prev ? { ...prev, end: pt } : null);
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
        e.currentTarget.releasePointerCapture(e.pointerId);
    }
    
    if (e.button === 1 || e.button === 2) {
       isPanning.current = false;
       return;
    }

    if (drawingNewLine) {
      const dist = Math.hypot(drawingNewLine.start.x - drawingNewLine.end.x, drawingNewLine.start.y - drawingNewLine.end.y);
      if (dist > 10) {
        setLines(prev => [...prev.filter(l => l.type !== 'constraint' || drawingNewLine.type !== 'constraint'), drawingNewLine]);
      } else {
        setSelectedLineId(null);
      }
      setDrawingNewLine(null);
    }
    draggingPointRef.current = null;
  };
  
  // Math & Perspective Evaluation
  const perspectiveData = useMemo(() => {
    const xLines = lines.filter(l => l.type === 'x');
    const yLines = lines.filter(l => l.type === 'y');
    const zLines = lines.filter(l => l.type === 'z');
    
    const VPx = xLines.length >= 2 ? getLineIntersection(xLines[0], xLines[1]) : null;
    const VPy = yLines.length >= 2 ? getLineIntersection(yLines[0], yLines[1]) : null;
    const VPz = zLines.length >= 2 ? getLineIntersection(zLines[0], zLines[1]) : null;

    const cx = imgSize.w / 2;
    const cy = imgSize.h / 2;
    
    let f = null;
    if (VPx && VPy) f = calculateFocalLength(VPx, VPy, cx, cy);
    if (!f && VPx && VPz) f = calculateFocalLength(VPx, VPz, cx, cy);
    if (!f) f = metadataFocalPixels || Math.max(imgSize.w, imgSize.h);

    const basis = getOrthogonalBasis(VPx, VPy, VPz, f, cx, cy);

    return { VPx, VPy, VPz, f, cx, cy, basis };
  }, [lines, imgSize, metadataFocalPixels]);

  // Constraints and measuring scale
  const scaleData = useMemo(() => {
    if (!perspectiveData || !perspectiveData.basis) return null;
    const cLine = lines.find(l => l.type === 'constraint');
    if (!cLine || !cLine.lengthInput) return 1; // Default to 1 for generic 'u' units
    
    const unscaled = getUnscaledDistanceRobust(
      cLine.start, cLine.end, 
      perspectiveData.basis,
      constraintPlane,
      perspectiveData.f, perspectiveData.cx, perspectiveData.cy
    );
    if (!unscaled || unscaled === 0) return 1;
    return cLine.lengthInput / unscaled;
  }, [perspectiveData, lines, constraintPlane]);

  useEffect(() => {
    onScaleDetermined(scaleData);
  }, [scaleData, onScaleDetermined]);

  // Calculate CSS Transform for Ortho Mode using precise matrix3d mapping
  const orthoTransformStyle = useMemo(() => {
    if (mode !== 'ortho' || !perspectiveData || !perspectiveData.basis) return {};
    const { Rx, Ry, Rz } = perspectiveData.basis;
    
    let col1 = [Rx[0], Rx[1], Rx[2], 0];
    let col2 = [Ry[0], Ry[1], Ry[2], 0];
    let col3 = [Rz[0], Rz[1], Rz[2], 0];

    // Note: Standard right handed rules map CSS coordinates:
    if (measurePlane === 'XZ') {
      // Floor (XZ Plane)
      col2 = [-Rz[0], -Rz[1], -Rz[2], 0];
      col3 = [Ry[0], Ry[1], Ry[2], 0];
    } else if (measurePlane === 'YZ') {
      // Side (YZ Plane)
      col1 = [-Rz[0], -Rz[1], -Rz[2], 0];
      col3 = [Rx[0], Rx[1], Rx[2], 0];
    }

    const matrix = [
      ...col1, 
      ...col2, 
      ...col3,
      0, 0, 0, 1
    ];

    return {
      transform: `translateZ(-${perspectiveData.f}px) matrix3d(${matrix.join(',')})`,
      transformOrigin: `${perspectiveData.cx}px ${perspectiveData.cy}px`
    };
  }, [mode, perspectiveData, measurePlane]);

  if (mode === 'ortho') {
      return (
        <div className="w-full h-full bg-slate-900 overflow-hidden flex items-center justify-center">
           <div 
             className="relative border border-slate-700 bg-black/50" 
             style={{ 
               width: '100%', height: '100%', 
               perspective: `${perspectiveData?.f || 1000}px`,
               transformStyle: 'preserve-3d',
               display: 'flex', alignItems: 'center', justifyContent: 'center',
               overflow: 'hidden'
             }}>
              <img 
                src={imageUrl} 
                alt="Ortho Base" 
                className="absolute max-w-none origin-top-left transition-all duration-700 pointer-events-none opacity-80"
                style={{
                  width: `${imgSize.w}px`,
                  height: `${imgSize.h}px`,
                  left: `calc(50% - ${perspectiveData?.cx || 0}px)`,
                  top: `calc(50% - ${perspectiveData?.cy || 0}px)`,
                  ...orthoTransformStyle
                }}
              />
              <div className="absolute top-4 left-4 p-3 bg-black/60 rounded-md text-white text-sm z-50">
                 Currently viewing Orthographic Projection of: 
                 <p className="font-bold text-blue-400">
                    {measurePlane === 'XY' ? 'Facade (XY)' : measurePlane === 'XZ' ? 'Floor (XZ)' : 'Side (YZ)'}
                 </p>
                 <p className="text-xs text-slate-400 mt-1">Change "Measure Plane" in sidebar to pivot.</p>
              </div>
           </div>
        </div>
      );
  }

  const allLinesToRender = drawingNewLine ? [...lines, drawingNewLine] : lines;
  const hitRadius = Math.max(imgSize.w, imgSize.h) * 0.02 / transform.scale; 
  const crosshairSize = Math.max(imgSize.w, imgSize.h) * 0.01 / transform.scale;

  return (
    <div 
      ref={containerRef}
      className="relative w-full h-full bg-slate-900 overflow-hidden cursor-crosshair"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerLeave={handlePointerUp}
      onContextMenu={(e) => e.preventDefault()}
      style={{ touchAction: 'none' }}
    >
      <div 
        className="absolute inset-0 origin-top-left"
        style={{ 
          width: imgSize.w, 
          height: imgSize.h, 
          transform: `translate(${transform.x}px, ${transform.y}px) scale(${transform.scale})` 
        }}
      >
        <img 
          src={imageUrl} 
          alt="Target" 
          className="absolute inset-0 w-full h-full object-contain pointer-events-none select-none transition-all" 
          style={{
             filter: showDepthMap ? 'grayscale(100%) contrast(150%)' : 'none'
          }}
          draggable={false}
        />
        <svg 
          ref={svgRef}
          viewBox={`0 0 ${imgSize.w} ${imgSize.h}`} 
          className="absolute inset-0 w-full h-full overflow-visible z-10"
          preserveAspectRatio="xMidYMid meet"
          id="export-svg-layer"
        >
          {/* Extended Lines for Vanishing Points during Setup Mode */}
          {mode === 'setup' && perspectiveData && (
            <g className="opacity-30 pointer-events-none">
              {perspectiveData.VPx && perspectiveData.VPx[2] !== 0 && lines.filter(l => l.type === 'x').map(l => (
                  <line key={`vp1-${l.id}`} x1={l.start.x} y1={l.start.y} x2={perspectiveData.VPx![0] / perspectiveData.VPx![2]} y2={perspectiveData.VPx![1] / perspectiveData.VPx![2]} stroke="#ef4444" strokeWidth={1} vectorEffect="non-scaling-stroke" strokeDasharray="10,10" />
              ))}
              {perspectiveData.VPy && perspectiveData.VPy[2] !== 0 && lines.filter(l => l.type === 'y').map(l => (
                  <line key={`vp2-${l.id}`} x1={l.start.x} y1={l.start.y} x2={perspectiveData.VPy![0] / perspectiveData.VPy![2]} y2={perspectiveData.VPy![1] / perspectiveData.VPy![2]} stroke="#22c55e" strokeWidth={1} vectorEffect="non-scaling-stroke" strokeDasharray="10,10" />
              ))}
              {perspectiveData.VPz && perspectiveData.VPz[2] !== 0 && lines.filter(l => l.type === 'z').map(l => (
                  <line key={`vp3-${l.id}`} x1={l.start.x} y1={l.start.y} x2={perspectiveData.VPz![0] / perspectiveData.VPz![2]} y2={perspectiveData.VPz![1] / perspectiveData.VPz![2]} stroke="#3b82f6" strokeWidth={1} vectorEffect="non-scaling-stroke" strokeDasharray="10,10" />
              ))}
            </g>
          )}

          {allLinesToRender.map(l => {
            let stroke = '#06b6d4'; // cyan-500 for constraint
            if (l.type === 'x') stroke = '#ef4444'; // red-500
            if (l.type === 'y') stroke = '#22c55e'; // green-500
            if (l.type === 'z') stroke = '#3b82f6'; // blue-500
            if (l.type === 'measure') stroke = '#f97316'; // orange-500
            
            const isSelected = selectedLineId === l.id;
            
            // Calc measure display
            let lengthDisplay = '';
            const isScaleSet = lines.some(line => line.type === 'constraint' && line.lengthInput);
            const unit = isScaleSet ? 'mm' : 'u';
            
            if (l.type === 'measure' && perspectiveData && perspectiveData.basis && scaleData) {
              const uDist = getUnscaledDistanceRobust(l.start, l.end, perspectiveData.basis, measurePlane, perspectiveData.f, perspectiveData.cx, perspectiveData.cy);
              if (uDist) {
                const num = uDist * scaleData;
                lengthDisplay = `${num.toFixed(0)} ${unit}`;
              } else {
                 lengthDisplay = 'N/A';
              }
            } else if (l.type === 'constraint' && l.lengthInput) {
               lengthDisplay = `${l.lengthInput} ${unit}`;
            }

            return (
              <g key={l.id}>
                {/* Visual Line */}
                <line 
                  x1={l.start.x} y1={l.start.y} 
                  x2={l.end.x} y2={l.end.y} 
                  stroke={stroke} 
                  strokeWidth={isSelected ? 3 : 1.5}
                  strokeDasharray="6,4"
                  vectorEffect="non-scaling-stroke"
                  strokeLinecap="round"
                  className="pointer-events-none drop-shadow-md"
                />
                
                {/* Visual Crosshairs */}
                <path 
                  d={`M ${l.start.x - crosshairSize} ${l.start.y} L ${l.start.x + crosshairSize} ${l.start.y} M ${l.start.x} ${l.start.y - crosshairSize} L ${l.start.x} ${l.start.y + crosshairSize}`}
                  stroke={stroke} 
                  strokeWidth={2} 
                  vectorEffect="non-scaling-stroke"
                  className="pointer-events-none drop-shadow-md" 
                />
                <path 
                  d={`M ${l.end.x - crosshairSize} ${l.end.y} L ${l.end.x + crosshairSize} ${l.end.y} M ${l.end.x} ${l.end.y - crosshairSize} L ${l.end.x} ${l.end.y + crosshairSize}`}
                  stroke={stroke} 
                  strokeWidth={2} 
                  vectorEffect="non-scaling-stroke"
                  className="pointer-events-none drop-shadow-md" 
                />

                {/* Measurement Text */}
                {lengthDisplay && (
                   <text 
                     x={(l.start.x + l.end.x)/2} 
                     y={(l.start.y + l.end.y)/2 - (dimensionSize / transform.scale)}
                     fill={stroke}
                     fontWeight="bold"
                     fontSize={dimensionSize / transform.scale}
                     textAnchor="middle"
                     className="font-mono pointer-events-none select-none"
                     style={{ 
                        filter: 'drop-shadow(0px 1px 2px rgba(0,0,0,0.9)) drop-shadow(0px 0px 4px rgba(0,0,0,1))'
                     }}
                   >
                     {lengthDisplay}
                   </text>
                )}
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
}
