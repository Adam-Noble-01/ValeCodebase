import React, { useState, useCallback } from 'react';
import exifr from 'exifr';
import { Upload, Crosshair, Ruler, SquarePen, AlertCircle, Info, Trash2, Download } from 'lucide-react';
import PerspectiveCanvas, { AppMode, DrawnLine } from './components/PerspectiveCanvas';

export default function App() {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [lines, setLines] = useState<DrawnLine[]>([]);
  const [mode, setMode] = useState<AppMode>('setup');
  const [selectedLineId, setSelectedLineId] = useState<string | null>(null);
  const [scale, setScale] = useState<number | null>(null);
  const [metadataFocalPixels, setMetadataFocalPixels] = useState<number | null>(null);
  
  // New Settings
  const [dimensionSize, setDimensionSize] = useState<number>(20);
  const [measurePlane, setMeasurePlane] = useState<'XZ' | 'XY' | 'YZ'>('XZ');
  const [constraintPlane, setConstraintPlane] = useState<'XZ' | 'XY' | 'YZ'>('XZ');
  const [showDepthMap, setShowDepthMap] = useState<boolean>(false);

  const onDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      await processImageConfig(file);
    }
  }, []);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      await processImageConfig(file);
    }
  };

  const processImageConfig = async (file: File) => {
    const url = URL.createObjectURL(file);
    setImageUrl(url);
    setLines([]);
    setMode('setup');
    
    try {
      const meta = await exifr.parse(file, { tiff: true, exif: true });
      if (meta && meta.FocalLengthIn35mmFormat) {
        const img = new Image();
        img.src = url;
        img.onload = () => {
          const maxDim = Math.max(img.width, img.height);
          const f_px = (meta.FocalLengthIn35mmFormat / 36) * maxDim;
          setMetadataFocalPixels(f_px);
        };
      }
    } catch (err) {
      console.warn("Could not read EXIF data", err);
    }
  };

  const handleHiddenAlign = () => {
     setShowDepthMap(prev => !prev);
     // Simulate hidden B&W "auto-align" heuristic by snapping lines to generic architectural bounds
     if (!imageUrl) return;
     const img = new Image();
     img.src = imageUrl;
     img.onload = () => {
         const w = img.width;
         const h = img.height;
         setLines(prev => {
             const nonSetup = prev.filter(l => !['x','y','z'].includes(l.type));
             return [
                 ...nonSetup,
                 { id: `x1_${Date.now()}`, type: 'x', start: { x: w * 0.1, y: h * 0.7 }, end: { x: w * 0.9, y: h * 0.75 } },
                 { id: `x2_${Date.now()}`, type: 'x', start: { x: w * 0.1, y: h * 0.3 }, end: { x: w * 0.9, y: h * 0.25 } },
                 { id: `y1_${Date.now()}`, type: 'y', start: { x: w * 0.6, y: h * 0.8 }, end: { x: w * 0.9, y: h * 0.9 } }, 
                 { id: `y2_${Date.now()}`, type: 'y', start: { x: w * 0.6, y: h * 0.4 }, end: { x: w * 0.8, y: h * 0.6 } }, 
                 { id: `z1_${Date.now()}`, type: 'z', start: { x: w * 0.2, y: h * 0.1 }, end: { x: w * 0.18, y: h * 0.9 } }, 
                 { id: `z2_${Date.now()}`, type: 'z', start: { x: w * 0.8, y: h * 0.1 }, end: { x: w * 0.82, y: h * 0.9 } }, 
             ];
         });
     };
  };

  const exportCanvas = () => {
    // Basic export drawing the image and SVG to a hidden canvas, then triggering download
    const imgEl = document.querySelector('img[alt="Target"]') as HTMLImageElement;
    const svgEl = document.getElementById('export-svg-layer') as unknown as SVGSVGElement | null;
    if (!imgEl || !svgEl) return;

    const canvas = document.createElement('canvas');
    canvas.width = imgEl.naturalWidth || imgEl.width;
    canvas.height = imgEl.naturalHeight || imgEl.height;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Draw base image (respect grayscale filter if active)
    if (showDepthMap) {
      ctx.filter = 'grayscale(100%) contrast(150%)';
    }
    ctx.drawImage(imgEl, 0, 0, canvas.width, canvas.height);
    ctx.filter = 'none';

    // Serialize SVG
    const svgData = new XMLSerializer().serializeToString(svgEl);
    
    // Replace CSS vector-effect and classes with inline styles in export SVG string because Canvas won't read external CSS properly
    let svgWithDims = svgData
          .replace(/<svg /, `<svg width="${canvas.width}" height="${canvas.height}" style="background-color: transparent;" `)
          .replace(/vector-effect="non-scaling-stroke"/g, 'vector-effect="non-scaling-stroke"')
          .replace(/className="[^"]*"/g, '');

    const svgBlob = new Blob([svgWithDims], { type: 'image/svg+xml;charset=utf-8' });
    const BlobURL = window.URL || window.webkitURL;
    const blobURL = BlobURL.createObjectURL(svgBlob);

    const svgImg = new Image();
    svgImg.onload = () => {
      ctx.drawImage(svgImg, 0, 0, canvas.width, canvas.height);
      BlobURL.revokeObjectURL(blobURL);
      
      const a = document.createElement('a');
      a.href = canvas.toDataURL('image/png');
      a.download = 'PhotoMeasurement_Export.png';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    };
    svgImg.crossOrigin = 'anonymous';
    svgImg.src = blobURL;
  };

  const selectedLine = lines.find(l => l.id === selectedLineId);

  return (
    <div className="flex h-screen w-full bg-slate-950 text-slate-200 font-sans">
      {/* Sidebar */}
      <div className="w-80 border-r border-slate-800 bg-slate-900 flex flex-col shrink-0">
        {/* Header - Contains hidden alignment trigger area */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between relative">
          <h1 className="text-lg font-bold flex items-center gap-2">
            <Ruler className="text-blue-500" />
            PhotoMeasurement
          </h1>
          <div 
             className="absolute right-2 top-2 w-8 h-8 cursor-crosshair opacity-0 hover:opacity-10 transition-opacity bg-white rounded-full z-10"
             onClick={handleHiddenAlign}
             title="Auto-Align (Depth Map Preview)"
          />
        </div>

        {!imageUrl ? (
          <div className="p-6 flex flex-col gap-4 text-sm text-slate-400">
            <p>Welcome! Upload a photograph of a building or object to start measuring.</p>
            <label className="flex items-center justify-center p-8 border-2 border-dashed border-slate-700 rounded-lg cursor-pointer hover:border-blue-500 hover:text-blue-400 transition-colors">
              <span className="flex flex-col items-center gap-2">
                <Upload size={24} />
                <span>Choose Image</span>
              </span>
              <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
            </label>
          </div>
        ) : (
          <div className="flex-1 flex flex-col overflow-y-auto">
             <div className="p-4 border-b border-slate-800 flex flex-col gap-2">
               <div className="text-xs text-slate-500 mb-2 font-medium">Pan: Right-Click | Zoom: Scroll</div>
               <button 
                  onClick={() => setMode('setup')}
                  className={`flex items-center gap-3 p-3 rounded-md transition-colors ${mode === 'setup' ? 'bg-blue-600/20 text-blue-400 ring-1 ring-blue-500/50' : 'hover:bg-slate-800'}`}
               >
                 <SquarePen size={18} className="shrink-0" />
                 <div className="text-left">
                   <div className="font-medium text-sm">1. Setup Perspective</div>
                   <div className="text-xs text-slate-500 line-clamp-1">Align X/Y/Z perspective lines</div>
                 </div>
               </button>
               <button 
                  onClick={() => setMode('constraint')}
                  className={`flex items-center gap-3 p-3 rounded-md transition-colors ${mode === 'constraint' ? 'bg-blue-600/20 text-blue-400 ring-1 ring-blue-500/50' : 'hover:bg-slate-800'}`}
               >
                 <Crosshair size={18} className="shrink-0" />
                 <div className="text-left">
                   <div className="font-medium text-sm">2. Set Scale Constraint</div>
                   <div className="text-xs text-slate-500 line-clamp-1">Draw real-world reference</div>
                 </div>
               </button>
               <button 
                  onClick={() => setMode('measure')}
                  className={`flex items-center gap-3 p-3 rounded-md transition-colors ${mode === 'measure' ? 'bg-blue-600/20 text-blue-400 ring-1 ring-blue-500/50' : 'hover:bg-slate-800'}`}
               >
                 <Ruler size={18} className="shrink-0" />
                 <div className="text-left">
                   <div className="font-medium text-sm">3. Measure</div>
                   <div className="text-xs text-slate-500 line-clamp-1">Draw lines on working plane</div>
                 </div>
               </button>
               <button 
                  onClick={() => setMode('ortho')}
                  className={`flex items-center gap-3 p-3 rounded-md transition-colors ${mode === 'ortho' ? 'bg-blue-600/20 text-blue-400 ring-1 ring-blue-500/50' : 'hover:bg-slate-800'}`}
               >
                 <SquarePen size={18} className="shrink-0" />
                 <div className="text-left">
                   <div className="font-medium text-sm">4. Warp To Ortho</div>
                   <div className="text-xs text-slate-500 line-clamp-1">Flatten image to ortho plane</div>
                 </div>
               </button>
             </div>

             <div className="p-4 flex-1 flex flex-col gap-4">
               {mode === 'setup' && (
                 <>
                   <div className="bg-blue-950/40 p-3 rounded-lg text-sm border border-blue-900/50 flex gap-3 text-blue-200">
                     <Info className="shrink-0 text-blue-400" size={18} />
                     <p>Align the <b>Red (Width)</b>, <b>Green (Depth)</b>, and <b>Blue (Height)</b> lines to parallel features.</p>
                   </div>
                   <div className="text-xs text-slate-500">
                     <div>Exif Focal Length: {metadataFocalPixels ? 'Loaded' : 'Not found (using fallback)'}</div>
                   </div>
                 </>
               )}

               {mode === 'constraint' && (
                 <>
                   <div className="bg-blue-950/40 p-3 rounded-lg text-sm border border-blue-900/50 flex gap-3 text-blue-200">
                     <Info className="shrink-0 text-blue-400" size={18} />
                     <p>Draw a line over a known dimension and input its true length in mm.</p>
                   </div>

                   <div className="p-3 bg-slate-800 rounded-md border border-slate-700">
                      <label className="text-xs text-slate-400 block mb-2">Constraint Plane</label>
                      <div className="flex gap-2">
                        {(['XZ', 'XY', 'YZ'] as const).map(plane => (
                          <button
                            key={plane}
                            onClick={() => setConstraintPlane(plane)}
                            className={`flex-1 px-2 py-1.5 text-[10px] rounded border transition-colors ${constraintPlane === plane ? 'bg-cyan-600 border-cyan-500 text-white' : 'bg-slate-900 border-slate-700 text-slate-400 hover:border-slate-500'}`}
                          >
                            {plane === 'XY' && 'Facade (XY)'}
                            {plane === 'XZ' && 'Floor (XZ)'}
                            {plane === 'YZ' && 'Side (YZ)'}
                          </button>
                        ))}
                      </div>
                   </div>

                   {lines.filter(l => l.type === 'constraint').map((l, i) => (
                      <div key={l.id} className="p-3 bg-slate-800 rounded-md space-y-2 border border-slate-700">
                        <div className="text-xs text-slate-400">Constraint #{i+1}</div>
                        <input 
                           type="number"
                           className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-sm"
                           placeholder="Length in mm (e.g. 1000)"
                           value={l.lengthInput || ''}
                           onChange={(e) => {
                              const val = parseFloat(e.target.value);
                              setLines(lines.map(line => line.id === l.id ? { ...line, lengthInput: isNaN(val) ? undefined : val } : line));
                           }}
                        />
                        <button onClick={() => setLines(lines.filter(line => line.id !== l.id))} className="text-xs text-red-400 hover:underline">
                          Remove
                        </button>
                      </div>
                   ))}
                   
                   {lines.filter(l => l.type === 'constraint').length === 0 && (
                     <p className="text-sm text-yellow-500/80 mt-2">Click and drag on the image to draw your constraint line.</p>
                   )}
                 </>
               )}

               {(mode === 'measure' || mode === 'ortho') && (
                 <>
                   {/* Measurement Settings */}
                   <div className="p-3 bg-slate-800 rounded-md space-y-4 border border-slate-700">
                     <div>
                       <label className="text-xs text-slate-400 block mb-2">{mode === 'ortho' ? 'Warp Target Plane' : 'Measure Plane'}</label>
                       <div className="flex gap-2">
                         {(['XZ', 'XY', 'YZ'] as const).map(plane => (
                           <button
                             key={plane}
                             onClick={() => setMeasurePlane(plane)}
                             className={`flex-1 px-2 py-1.5 text-[10px] rounded border transition-colors ${measurePlane === plane ? 'bg-blue-600 border-blue-500 text-white' : 'bg-slate-900 border-slate-700 text-slate-400 hover:border-slate-500'}`}
                           >
                             {plane === 'XY' && 'Facade (XY)'}
                             {plane === 'XZ' && 'Floor (XZ)'}
                             {plane === 'YZ' && 'Side (YZ)'}
                           </button>
                         ))}
                       </div>
                     </div>
                     {mode === 'measure' && (
                       <div>
                          <div className="flex justify-between items-end mb-2">
                            <label className="text-xs text-slate-400 block">Dimensions Size</label>
                            <span className="text-xs text-slate-500">{dimensionSize}px</span>
                          </div>
                          <input 
                            type="range" 
                            min="10" 
                            max="80" 
                            value={dimensionSize} 
                            onChange={(e) => setDimensionSize(Number(e.target.value))}
                            className="w-full accent-blue-500"
                          />
                       </div>
                     )}
                   </div>

                   {mode === 'measure' && !lines.some(l => l.type === 'constraint' && l.lengthInput) && (
                     <div className="text-yellow-400 text-sm flex gap-2"><AlertCircle size={16} className="shrink-0"/> <span className="leading-tight">Warning: Measuring in perspective units (u). Add constraints for mm.</span></div>
                   )}
                 </>
               )}

               {/* Selected Line Actions */}
               {selectedLine && (mode === 'measure' || mode === 'constraint') && (
                 <div className="mt-auto border-t border-slate-800 pt-4">
                   <div className="flex items-center justify-between bg-slate-800 p-2 rounded">
                     <span className="text-xs font-medium px-1">Selected Line</span>
                     <button onClick={() => {
                        setLines(lines.filter(l => l.id !== selectedLine.id));
                        setSelectedLineId(null);
                     }} className="text-red-400 p-1.5 hover:bg-slate-700 rounded-md flex gap-1 items-center text-xs transition-colors">
                        <Trash2 size={14} /> Delete
                     </button>
                   </div>
                 </div>
               )}

               {/* Export Button */}
               <div className="mt-auto pt-4">
                 <button 
                   onClick={exportCanvas}
                   className="w-full flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 p-3 rounded-lg transition-colors font-medium text-sm"
                 >
                   <Download size={18} /> Export Image
                 </button>
               </div>
             </div>
          </div>
        )}
      </div>

      {/* Main Canvas Area */}
      <div 
        className="flex-1 overflow-hidden bg-slate-950 relative border-l border-slate-800"
        onDragOver={(e) => e.preventDefault()}
        onDrop={onDrop}
      >
        {imageUrl ? (
          <PerspectiveCanvas 
            imageUrl={imageUrl} 
            lines={lines} 
            setLines={setLines} 
            mode={mode} 
            selectedLineId={selectedLineId}
            setSelectedLineId={setSelectedLineId}
            onScaleDetermined={setScale}
            metadataFocalPixels={metadataFocalPixels}
            dimensionSize={dimensionSize}
            constraintPlane={constraintPlane}
            measurePlane={measurePlane}
            showDepthMap={showDepthMap}
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center text-slate-600 p-8 text-center pointer-events-none">
            <div className="flex flex-col items-center gap-4 border-2 border-dashed border-slate-800 rounded-2xl p-12">
              <Upload size={48} className="text-slate-700" />
              <p className="text-lg">Drag and drop a photograph here to begin</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
