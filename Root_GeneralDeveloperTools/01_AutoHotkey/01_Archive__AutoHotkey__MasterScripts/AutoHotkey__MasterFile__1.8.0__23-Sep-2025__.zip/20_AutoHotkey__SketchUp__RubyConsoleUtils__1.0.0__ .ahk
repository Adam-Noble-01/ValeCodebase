#Requires AutoHotkey v1.1+  ; Ensure you're using AHK v1.1+ for UTF-8 support
#Warn  ; Enables warnings to assist with detecting common errors.
SendMode Input  ; Recommended for new scripts due to its superior speed and reliability.
#NoEnv  ; Recommended for performance and compatibility with future AutoHotkey releases.
SetWorkingDir %A_ScriptDir%  ; Ensures a consistent starting directory.
#SingleInstance, Force

; =============================================================================
; PYTHON SCRIPTS ROOT DIRECTORY - SINGLE SOURCE OF TRUTH
; =============================================================================
; All Python script references use relative paths from this root directory
PYTHON_ROOT := "D:\10_CoreLib__ValeCodebase\Root_GeneralDeveloperTools\02_Python"
; =============================================================================

; region  |  - - - - - - - - - - - - - - - - - - - - - - - - |  VERSION NOTES  | - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  |

    ; Version 0.9.0 | 19-Sep-2025 | Added new Hotstring - SketchUp Ruby Console Clear Utility
    ; Version 1.0.0 | 19-Sep-2025 | Added Util.ReportTags Hotstring - this will return a list of all tags in the current model

; |--------------------------------------------------------------------------------------------------------------------------------|

; - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
; #region  - - - |  Clear Ruby Console  | - -
::;r_Clear::
::;r__Clear::
::;rb_Clear::
::;rb__Clear::
::;r_ClearConsole::
::;r__ClearConsole::
::;rb_ClearConsole::
::;rb__ClearConsole::
{
    SendRaw, def clear_console; puts "\n" * 100; end; clear_console
    Sleep, 50
    Send, {Enter}
    return
}
; #endregion | - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |

; - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
; #region  - - - - |  Util.ReportTags  | - - - - - 
; Util.ReportTags - this will return a list of all tags in the current model
::;r_ReportTags::
::;r__ReportTags::
::;rb_ReportTags::
::;rb__ReportTags::
{
    SendRaw, Util.ReportTags
    Sleep, 50
    Send, {Enter}
    return
}
; #endregion | - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |


; - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
; #region  - - - - |  Util.MoveDeepNestedTagsToUntagged  | - - - - - 
; Util.MoveDeepNestedTagsToUntagged - this will move deeply nested tags to the untagged layer
::;r_UntagSelection::
::;r__UntagSelection::
::;rb_UntagSelection::
::;rb__UntagSelection::
::;r_UntagSelectedEntities::
::;r__UntagSelectedEntities::
::;rb_UntagSelectedEntities::
::;rb__UntagSelectedEntities::

{
    SendRaw, Util.MoveDeepNestedTagsToUntagged
    Sleep, 50
    Send, {Enter}
    return
}
; #endregion | - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |


; - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
; #region  - - - - |  SimpleWindowMaker  | - - - - - 
; SimpleWindowMaker.Ceate3dObject__PlaneToWindow - this will create a window from a plane
::;r_PlaneToWindow::
::;r__PlaneToWindow::
::;rb_PlaneToWindow::
::;rb__PlaneToWindow::
::;r_MakeSimpleWindow::
::;r__MakeSimpleWindow::
::;rb_MakeSimpleWindow::
::;rb__MakeSimpleWindow::
{
    SendRaw, SimpleWindowMaker.Ceate3dObject__PlaneToWindow
    Sleep, 50
    Send, {Enter}
    return
}
; #endregion | - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |

